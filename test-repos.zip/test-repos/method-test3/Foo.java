public class Foo{
	public void methodOnlyChangedOne(){
		int b = 2;
		int c = 3;
	}

	public void methodChangedByTwo(){
		int b = 2;
		int c = 3;
		String a = "Alexander Knecht changhed this";
	}

	public void methodChangedByThree(){
		int b = 2;
		int c = 3;
	}

	public void methodChangedByTwoWithSameNameButDifferentEmail(){
		int a = 1;
		System.out.println("Tobias Famos again but with different email");
	}

	private void methodChangedByTwoAuthors(){
		int a = 1;
		System.out.println("Changed By Tobias Famos Again")
	}
	
	private void methodChangedByTwoDifferentTwice(){
		int a = 1;
		System.out.println("Second Change by Rudi Fritz")
	}
}