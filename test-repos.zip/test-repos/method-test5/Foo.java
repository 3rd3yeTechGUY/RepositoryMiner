public class Foo{
	public void noConditionInMethod(){
		int b = 2;
		int c = 3;
	}
	public void neverAConditionChange(){
		if(true){
			int b = 2;
			int c = 3;
		}
		
	}

	public void conditionChangedOnce(){
		if(false){
			int b = 2;
			int c = 3;
		}
	}

	public int conditionChangedTwice(){
		int a = 12;
		if( 51>52){
			a = 1;
		}
		int b = 2;
		int c = 3;
		return 1;
	}

	public int twoDifferentConditionStatementsAdded(){
		if(3 == 3){
			int a = 1;
			return 1;
		}
		if(true){
			return 1;
		}
	}

	public void oneConditionAddedAndRemovedAfter(){
		int a = 1;
	}

	public void oneElseNeverChanged(){
		int a = 0;
		if(a == 1){
			return 1
		}else{
			return 0;
		}
	}

	public void oneDeletedAfter(){
		int a = 0;
		if(a == 1){
			return 1
		}
	}
	public void twoElseOneDeleted(){
		int a = 0;
		if(a == 1){
			a= 1
		}
		if(a == 1){
			return 1
		}else{
			return 0;
		}
	}
	public void fourElseAddedNoDeleted(){
		int a = 0;
		if(a == 1){
			a=1
		}else{
			a=0;
		}
		if(a == 1){
			a=1
		}else{
			a=0;
		}
		if(a == 1){
			a=1
		}else{
			a=0;
		}
		if(a == 1){
			a=1
		}else{
			a=0;
		}
	}
	public void fourElseAddedAndDeleted(){
		int a = 0
		if(a == 1){
			a=1
		}
	}

	public void twoElseIfAddedOneDeleted(int a){
		if(a <1){
			a = 3;
		}else if(a == 2){
			a = 3;
		}
		return a;
	}
}