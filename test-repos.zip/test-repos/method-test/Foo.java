public class Foo{
	public void someFunction(){
		int a = 1;
		int b = 2;
		int c = 3;
	}

	public void someFunction2(){
		int a = 1;
		int b = 2;
		int c = 3;
	}

// Lots of comments
//
//
//
//
//
//
//
//
//
	public void someFunction3(){
		if(true){
		int a = 1;
		int b = 2;
		int c = 3;
		}
		
	}
}